# Projet final — LP Citroën Utilitaires Pro (v4)

Paquet prêt à déployer : **tracking URL corrigé** + **formulaire optimisé** (nombre de véhicules, neuf/occasion, type de carburant), toutes les données transmises au **CRM HelloLead** et au **Google Sheet**.

## Structure

```
.
├── index.html              ← LP (étape 1 enrichie de 3 critères)
├── style.css               ← styles (pastilles de critères)
├── script.js               ← tracking corrigé + validation + payloads Sheet/CRM
├── cookie-consent.js       ← CMP + notification de consentement
├── img/                    ← vos visuels (à conserver tels quels)
├── apercu/
│   └── apercu-formulaire-v4.html    ← aperçu visuel du formulaire, ouvrable dans un navigateur
├── docs/
│   ├── LISEZ-MOI-DEPLOIEMENT.md     ← à lire en premier : installation + vérifications
│   ├── CHANGELOG-v4.md              ← détail des changements et colonnes CRM ajoutées
│   ├── AUDIT-TRACKING.md            ← rapport d'audit du bug de tracking corrigé
│   └── PREUVE-TESTS.txt             ← trace des 26 contrôles automatisés (avant/après)
└── tests/
    ├── self-test.js                 ← autotest rejouable (18 contrôles)
    ├── README.md                    ← mode d'emploi de l'autotest
    └── resultats-autotest.txt       ← dernière trace d'exécution
```

## Démarrage rapide

1. Lire `docs/LISEZ-MOI-DEPLOIEMENT.md`.
2. Déployer `index.html`, `style.css`, `script.js`, `cookie-consent.js` (conserver `img/`).
3. Reproduire l'autotest si besoin :
   ```bash
   cd tests && npm i jsdom && node self-test.js
   ```

## Nouveaux champs du formulaire

| Champ | Options | Transmis au CRM sous |
|---|---|---|
| Nombre de véhicules | 1 · 2 · 3-5 · 6-10 · 10+ | `nb_vehicules` + `nb_vehicules_libelle` + `question_2`/`reponse_2` |
| Neuf ou occasion | Neuf · Occasion · Peu importe | `etat_vehicule` + `etat_vehicule_libelle` + `question_3`/`reponse_3` |
| Type de carburant | Électrique · Diesel · Hybride · Peu importe | `carburant` + `carburant_libelle` + `question_4`/`reponse_4` |

Modèle, nombre de véhicules, état et carburant sont **obligatoires** : l'étape 2 est bloquée tant qu'ils ne sont pas renseignés.

## Points à confirmer côté CRM (non bloquants)

1. Déclarer les nouvelles colonnes dans le contrat du `formId` (`ADW_LP_CITROEN_VU`).
2. `domaine` envoyé en dur : `ubepro.com` alors que la LP est en `www.ubepro.fr`.
3. Endpoint CRM : basculer `leadApiUrl` de `helloleadpreprod.fr` vers `mc.hellolead.pro` en production (`script.js`, ligne ~27).
