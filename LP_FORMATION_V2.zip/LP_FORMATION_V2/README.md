# UBEPRO — Formation Management PME & ETI

Version adaptée à partir des trois fichiers joints le 22/09/2026.

## Modifications

- Marque normalisée en **UBEPRO** dans le HTML.
- HTML aligné sur les sélecteurs réellement utilisés par le JavaScript fourni :
  - formulaire unique `#study-form` ;
  - exactement deux étapes `.form-step` ;
  - `.form-next`, `.form-back`, `.form-progress`, `.form-error`, `.form-success` ;
  - menu mobile `.menu-toggle` / `#mobile-nav` ;
  - onglets `data-tab` / `data-panel` ;
  - honeypot `website` et champs de tracking attendus.
- FAQ transformée en accordéons natifs `<details>/<summary>` : aucun second script ajouté.
- CSS optimisé pour les états `hidden`, le formulaire multi-étapes, le menu mobile et les largeurs de 320 à 1365 px.
- Les liens, textes de la page, sections, témoignages et visuels référencés ont été conservés autant que possible.

## JavaScript inchangé

`script.js` livré est une copie binaire exacte du fichier joint.

```text
e6ae6897669eed0083358435f1494d7dbaef112ce2be81c3512a399982afcdcb
```

Le formulaire exploite les clés déjà gérées par le JS (`solution`, `site`, `enjeu`, `nom`, `prenom`, `societe`, `mail`, `telephone`, `code_postal`). L'effectif est transmis via la clé `site`, car c'est la clé disponible dans le contrat du script. Le consentement sert à la validation côté formulaire mais, conformément au JavaScript inchangé, n'est pas inclus dans le payload envoyé.

## Vérification

**20/20 vérifications Chromium réussies**, incluant : formulaire, tracking URL, validation, téléphone, honeypot, réponse métier en erreur, succès, onglets, FAQ, menu mobile, affichage sans JavaScript et responsive à 320, 390, 560, 720, 1020 et 1365 px.

Les 6 POST de test ont été interceptés localement. Aucun appel de test n'a été envoyé au déploiement Google.

## Ressources visuelles

Les fichiers joints ne contenaient pas de dossier `img/`. Les chemins `img/...` présents dans le HTML ont été conservés ; les images et le favicon doivent être ajoutés avant publication.
