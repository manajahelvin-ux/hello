/* ============================================================
   ComparateurPro — LP V2
   Sections : état global → header → révélation → étapes du
   formulaire → validation → envoi → liens "aller au formulaire"
   → sticky CTA
   ============================================================ */
(function () {
  'use strict';
  document.documentElement.classList.add('js');
  var reduceMotion = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)').matches : false;

  /* === HEADER : état scrollé === */
  var hdr = document.querySelector('.hdr');
  function onHdr() { hdr.classList.toggle('scrolled', window.scrollY > 8); }
  window.addEventListener('scroll', onHdr, { passive: true });
  onHdr();

  /* === RÉVÉLATION AU SCROLL === */
  var rvEls = document.querySelectorAll('.hero-copy, .form-card, .why-left, .scene, .axe, .perso, .steps li, .zero, .final-in');
  rvEls.forEach(function (el) { el.classList.add('rv'); });
  if ('IntersectionObserver' in window && !reduceMotion) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) { e.target.classList.add('on'); io.unobserve(e.target); }
      });
    }, { threshold: 0.12 });
    rvEls.forEach(function (el) { io.observe(el); });
  } else {
    rvEls.forEach(function (el) { el.classList.add('on'); });
  }

  /* === FORMULAIRE 2 ÉTAPES === */
  var form = document.getElementById('lead-form');
  var step1 = document.getElementById('step-1');
  var step2 = document.getElementById('step-2');
  var prog1 = document.getElementById('prog-1');
  var prog2 = document.getElementById('prog-2');
  var formCard = document.getElementById('formulaire');
  formCard.setAttribute('tabindex', '-1');

  function selectedCovs() {
    return Array.prototype.map.call(form.querySelectorAll('input[name="couverture"]:checked'), function (c) { return c.value; });
  }
  function selectedSituation() {
    var s = form.querySelector('input[name="situation"]:checked');
    return s ? s.value : '';
  }
  function buildRecap() {
    document.getElementById('recap').textContent =
      'Votre demande : ' + selectedSituation() + ' · protections à regarder : ' + selectedCovs().join(', ') + '.';
  }
  function goToStep(n) {
    var toTop = function (el) { window.setTimeout(function () { el.focus({ preventScroll: false }); }, reduceMotion ? 0 : 250); };
    if (n === 1) {
      step2.hidden = true; step1.hidden = false;
      prog1.className = 'on'; prog2.className = '';
      toTop(form.querySelector('#pills input'));
    } else {
      buildRecap();
      step1.hidden = true; step2.hidden = false;
      prog1.className = 'done'; prog2.className = 'on';
      toTop(document.getElementById('f-nom'));
    }
  }

  /* === VALIDATION === */
  function setErr(id, input, bad) {
    document.getElementById(id).hidden = !bad;
    if (input) {
      if (bad) { input.setAttribute('aria-invalid', 'true'); }
      else { input.removeAttribute('aria-invalid'); }
    }
    return bad;
  }
  document.getElementById('next-1').addEventListener('click', function () {
    var firstBad = null;
    if (setErr('err-situation', null, !selectedSituation())) firstBad = form.querySelector('#pills input');
    if (setErr('err-couverture', null, selectedCovs().length === 0)) firstBad = firstBad || form.querySelector('.cov input');
    if (firstBad) { firstBad.focus(); return; }
    goToStep(2);
  });
  document.getElementById('back-2').addEventListener('click', function () { goToStep(1); });

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var firstBad = null;
    var nom = document.getElementById('f-nom');
    if (setErr('err-nom', nom, nom.value.trim().length < 2)) firstBad = nom;
    var email = document.getElementById('f-email');
    if (setErr('err-email', email, !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim()))) firstBad = firstBad || email;
    var tel = document.getElementById('f-tel');
    if (setErr('err-tel', tel, !/^[+0-9][0-9 .\-()]{5,}$/.test(tel.value.trim()))) firstBad = firstBad || tel;
    var consent = document.getElementById('f-consent');
    if (setErr('err-consent', consent, !consent.checked)) firstBad = firstBad || consent;
    if (firstBad) { firstBad.focus(); return; }

    var submitBtn = document.getElementById('submit-btn');
    submitBtn.disabled = true;
    submitBtn.textContent = 'Envoi en cours…';

    /* === INTÉGRATION ===
       Branchez ici votre endpoint réel (CRM / email / webhook) :
       fetch('https://votre-endpoint', { method: 'POST', body: new FormData(form) })
       Le bloc ci-dessous simule l'envoi pour la préversion. */
    window.setTimeout(function () {
      var ctx = document.getElementById('f-ctx').value;
      var mis = Array.prototype.map.call(form.querySelectorAll('.mis:checked'), function (m) { return m.value; });
      var sum = 'Vous demandez : ' + selectedCovs().join(', ') + '. Situation : ' + selectedSituation() + '.';
      if (ctx) { sum += ' Contexte : ' + ctx + '.'; }
      if (mis.length > 0) { sum += ' Précisions jointes : ' + mis.join(' ; ') + '.'; }
      document.getElementById('success-sum').textContent = sum;
      form.hidden = true;
      var ok = document.getElementById('form-success');
      ok.hidden = false;
      ok.setAttribute('tabindex', '-1');
      ok.focus();
    }, 900);
  });

  /* === LIENS "ALLER AU FORMULAIRE" : focus doux sur la carte === */
  document.querySelectorAll('[data-goto-form]').forEach(function (a) {
    a.addEventListener('click', function () {
      window.setTimeout(function () { formCard.focus({ preventScroll: true }); }, reduceMotion ? 0 : 400);
    });
  });

  /* === STICKY CTA MOBILE === */
  var sticky = document.getElementById('sticky-cta');
  var formVisible = false;
  if ('IntersectionObserver' in window) {
    new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { formVisible = en.isIntersecting; onSticky(); });
    }, { threshold: 0.08 }).observe(formCard);
  }
  function onSticky() { sticky.hidden = !(window.scrollY > 560 && !formVisible); }
  window.addEventListener('scroll', onSticky, { passive: true });
  onSticky();
})();
