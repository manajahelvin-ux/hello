# STRATÉGIE & LIVRAISON — LP « Assurances professionnelles · Consultants & sociétés de conseil » — ComparateurPro

Brief reçu : LP assurances professionnelles pour consultants et sociétés de conseil ; formulaire proposant RC Pro + Multirisque en axes prioritaires, et Santé / Prévoyance / Retraite individuelle en complément.
Brief assessment : complétude **moyenne** (cible ✓, offre ✓, point de conversion ✓, marque ✓ ; différenciateurs, preuves, marché et sortie de formulaire non fournis). Questions posées via ask_user → **ignorées par le client** → pipeline lancé avec hypothèses marquées, règle de véracité stricte.

Hypothèses `NON FOURNI — hypothèse` :
- H1 rôle : comparateur gratuit multi-assureurs, sans engagement.
- H2 preuves : aucune fournie → zéro chiffre/partenaire/avis inventé ; confiance par transparence du processus.
- H3 marché : France.
- H4 sortie de formulaire : demande traitée par un conseiller + comparaison reçue, sans engagement.

---

## 01 — RESEARCH & MARKET ANALYSIS

Vocabulaire et risques réels du conseil (vérifiés) : dommages immatériels consécutifs/**non consécutifs**, biens confiés / données / documents, manquements contractuels, propriété intellectuelle, exclusion cyber, fait des sous-traitants, territorialité, plafonds/franchises/sous-limites, défense & recours [1](https://magazine-economie.fr/quelles-activites-peuvent-etre-protegees-par-une-rc-pro-dans-le-secteur-informatique.html), [2](https://assuroweb.fr/article-choisir-rc-pro-consultant.html). La RC Pro du conseil n'est pas obligatoire légalement mais fréquemment exigée contractuellement (attestation pièce du contrat) [3](https://sos-rc-pro.fr/assurance-rc-pro/rc-conseil-pour-les-consultants/) — formulé qualitativement, sans % inventé.

Frustration marché n°1 des comparateurs : revente de coordonnées → harcèlement téléphonique [4](https://latribunewomensawards.fr/2026-08/devis-assurance-pro-rappels/). Patterns concurrents répétés : « devis en 2 min », compteurs sociaux (« 3 428 pros ce mois-ci »), promesses d'économies, bleu générique, poignées de main stock.

```yaml
market_patterns:
  common_headlines: "Comparez 3 devis gratuits en 2 min"
  common_ctas: "Obtenir mes devis"
  common_sections: hero formulaire + logos partenaires + témoignages + FAQ
  overused_phrases: "jusqu'à X% d'économies", "simple, rapide et efficace"
  overused_design_patterns: bleu assurance, badges, compteurs animés
market_gap:
  underserved_need: comparaison lue à la grille des risques du conseil, pas au prix d'appel
  communication_gap: aucun acteur ne parle "missions, livrables, données clients, sous-traitance"
  proof_gap: les comparateurs prouvent par des compteurs — personne par la méthode
  differentiation_opportunity: spécialisation verticale conseil + transparence de contact
```

## 02 — DIFFERENTIATION CONCURRENTIELLE

```yaml
differentiation:
  what_everyone_does: promesse de devis immédiats + compteurs + logos partenaires
  what_we_will_not_do: aucun chiffre inventé, aucun compteur, aucun logo partenaire, aucune promesse d'économie
  what_we_will_do_differently: éducation par le risque (checklist de vigilance) + transparence "zéro surprise de contact" + formulaire qualifiant par les missions
  unique_angle: "Votre RC Pro se juge sur ses exclusions, pas sur son prix d'appel"
  visual_signature: glyphe double-flèche de la marque, or + charbon, numérotation éditoriale serif
```

## 03 — CUSTOMER AWARENESS

```yaml
awareness:
  level: solution_aware
  reasoning: le consultant connaît la RC Pro (souvent exigée par un client) mais pas les critères qui font un bon contrat conseil
  required_explanation: ce qui distingue un contrat conseil d'un contrat générique (exclusions, plafonds, données, sous-traitance)
  required_proof: méthode lisible et transparence du processus (pas de fausse preuve sociale)
  recommended_page_length: moyenne-longue (éducation courte + conversion)
  recommended_cta_timing: CTA visible dès le hero, répété (header, sticky mobile, formulaire)
  vocabulary: missions, livrables, attestation, appels d'offres, portage, échéance, plafonds, franchises
```

## 04 — ANALYSE STRATÉGIQUE (9 QUESTIONS)

```yaml
strategy:
  who: consultant indépendant / gérant de société de conseil / porté salarial, 28-55 ans, en signature, renouvellement ou création
  concrete_problem: obtenir une couverture qui tient en cas de sinistre intellectuel, sans y passer dix soirées
  why_now: attestation exigée avant signature, appel d'offres, échéance annuelle, création
  main_objection: "encore un formulaire qui va me valoir dix appels téléphoniques"
  hidden_objection: "je ne comprends pas les petites lignes ; j'ai peur de l'exclusion au moment du sinistre"
  proof_needed: transparence du processus (qui contacte, pourquoi, usage des données) + compétence métier démontrée par le contenu
  why_this_offer: seul acteur qui compare sur la grille des risques du conseil
  why_different: page qui parle missions et exclusions, sans compteurs ni promesses d'économie
  why_click_now: une demande unique qualifiée évite de refaire cinq formulaires assureurs ; échéance/signature approchent
  uncopyable_element: la checklist de vigilance conseil (immateriel non consécutif, données/cyber, sous-traitance, territorialité, attestation) — contenu qui exige de connaître le métier
  current_frustration: jargon, devis incomparables, pression téléphonique
  desired_result: être correctement couvert, au juste prix, sans harcèlement
  emotional_driver: contrôle et sérénité (ne pas découvrir une exclusion le jour du sinistre)
  trust_trigger: transparence écrite ("zéro surprise de contact") + précision technique du contenu
  expected_action: remplir le formulaire (situation, axes, points de vigilance, contact, consentement)
```

Chaîne : attestation/exigence client (PROBLÈME) → mission signée sans vraie couverture (CONSÉQUENCE) → protéger revenu et crédibilité (MOTIVATION) → peur du spam et du jargon (OBJECTION) → méthode lisible + transparence (PREUVE) → CONFIANCE → comparaison qualifiée gratuite (DÉSIR) → formulaire (ACTION).

## 05 — ANGLE MARKETING

Principal : **reduction_du_risque** (le sinistre se joue dans les exclusions ; nous les vérifions une par une). Secondaire : **gain_de_temps** (une demande au lieu de cinq formulaires). Justification : audience solution_aware qui craint moins le prix que le trou de couverture ; le gain de temps reste le mécanisme du comparateur.

## 06 — CONCEPT & BIG IDEA

```yaml
concept:
  big_idea: "Une assurance de conseil ne se compare pas au prix d'appel : elle se compare aux exclusions."
  core_promise: une seule demande, des offres lues à la grille des risques réels de vos missions
  key_message: RC Pro et multirisque en priorité, santé/prévoyance/retraite en complément, sans engagement
  emotional_response: "enfin quelqu'un qui parle mon métier et pas un formulaire aveugle"
  strategic_angle: reduction_du_risque + gain_de_temps
  differentiation: checklist de vigilance interactive jointe à la demande
  visual_concept: le face-à-face (double flèche de la marque) comme motif récurrent
  memorable_element: "Joindre ces points à ma demande" — le diagnostic qui voyage vers le formulaire
```

## 07 — VISUAL CONCEPT

```yaml
visual_concept:
  metaphor: le face-à-face / la balance (glyphe double-flèche du logo)
  visual_story: chaque section oppose le réflexe générique (prix) et la lecture professionnelle (couvertures)
  hero_visual: diagnostic interactif à droite du H1 (pas de photo stock en hero)
  supporting_visuals: 1 photo éditoriale unique (section protection personnelle), glyphes SVG, numérotation serif
  composition: grilles asymétriques, colonne sticky "pourquoi spécialisé"
  visual_tension: charbon profond vs or, papier chaud
  focal_point: carte diagnostic puis carte formulaire
  brand_signature: filet or, surlignage or des mots-clés, encadrés double filet
```

## 08 — ARCHITECTURE UX

```yaml
sections:
  - hero + diagnostic: {objective: qualifier + capter, user_question: "est-ce qu'ils parlent de mon métier ?", role: attention/qualification}
  - pourquoi spécialisé (3 scènes): {objective: éduquer sur les exclusions, role: compréhension/intérêt}
  - axes comparés (RC Pro, multirisque, + perso): {objective: montrer le périmètre exact de comparaison, role: intérêt/confiance}
  - méthode (3 étapes + zéro surprise): {objective: lever l'objection spam/opacité, role: confiance}
  - FAQ (6 questions réelles): {objective: traiter portage, attestation 48h, prix, rappel, role: confiance/désir}
  - formulaire qualifiant: {objective: conversion, role: action}
```
Règle de suppression appliquée : pas de section témoignages (aucun fourni → ne pas en inventer), pas de bandeau logos, pas de section "avantages" générique.

## 09 — COPYWRITING

Ton : pair expert, direct, sans jargon vendeur. Phrases interdites du master prompt absentes (vérifié : aucun « solution innovante / leader / meilleur / simple rapide efficace / expertise unique »). H1 : « Consultants, comparez des assurances qui comprennent vos missions — pas seulement votre code NAF. » Chaque affirmation engageante est soit un fait de marché sourcé formulé qualitativement, soit un engagement du service (gratuit, sans engagement, usage des données limité au traitement).

## 10 — UX / IHM

Navigation sticky courte (4 ancres + CTA) ; chemin de conversion : diagnostic → CTA hero → formulaire. Friction réduite : 6 champs visibles max + sélections ; le diagnostic pré-remplit la demande (puces de vigilance + RC Pro coché). États gérés : erreurs inline, envoi, succès avec récapitulatif de la demande (écho de ce qui a été choisi).

## 11 — UI / DESIGN SYSTEM

```yaml
colors: {primary: "#1B2126", accent: "#C9A238", accent_text: "#7A5E17", background: "#FAF8F3", surface: "#FFFFFF", border: "#E6E0D3", tint: "#F5EBD2", error: "#B3261E", success: "#1E7B4D"}
typography: {display: "Iowan Old Style/Palatino/Georgia (serif système, zéro webfont)", body: "system-ui sans", h1: "clamp(2rem,4.6vw,3.25rem)"}
layout: {max_width: 1120, radius: 12/8, ombres discrètes, filets 1px}
```
Découle de la marque (charbon + or du logo) + cible B2B experte : sobriété éditoriale, aucun glassmorphism, aucun blob.

## 12 — DIRECTION ARTISTIQUE

Photo unique éditoriale (lumière naturelle, palette crème/charbon/laiton) pour humaniser la section protection personnelle ; iconographie = glyphe de marque décliné ; pas de dégradés décoratifs (un surlignage or fonctionnel) ; animations = révélations légères et micro-interactions d'état uniquement ; `prefers-reduced-motion` respecté.

## 13 — TRUST & PROOF SYSTEM

```yaml
trust:
  authority: contenu technique exact (immateriel non consécutif, biens confiés, fait des sous-traitants…)
  process_transparency: méthode en 3 étapes + "zéro surprise de contact"
  risk_reduction: gratuit, sans engagement, ne rien faire ne coûte rien
  guarantee: usage des données limité au traitement de la demande (engagement à tenir côté client)
  DATA NEEDED (à fournir par le client avant mise en ligne): n° ORIAS & statuts, assureurs partenaires, chiffres réels, témoignages vérifiés, politique de confidentialité & mentions légales complètes
```
Aucun témoignage affiché (règle 18 : non fournis → ne jamais en présenter comme réels).

## 14 — CRO

Value proposition spécifique dès le H1 ; différenciation visible (diagnostic) ; objection spam traitée deux fois (méthode + FAQ) ; CTA répétés et contextualisés ; formulaire court avec qualification à valeur ajoutée (les puces) ; réassurance sous chaque zone sensible ; succès avec récapitulatif (confirmation de ce qui part). Urgence légitime uniquement (signature/échéance) — pas de faux countdown.

## 15 — RESPONSIVE

Mobile first : nav réduite, sticky CTA bas d'écran (masqué quand le formulaire est visible), grille formulaire 1 colonne, cartes couverture 1 colonne, typo clamp. Tablettes : hero 1 colonne à 1000px. Desktop : grilles asymétriques, colonne sticky.

## 16 — SEO / PERFORMANCE

Title + meta description dédiés ; H1 unique ; structure H2/H3 sémantique ; JSON-LD Service + FAQPage ; alt descriptifs ; zéro webfont (stacks système) ; 1 PNG logo (246 Ko, transparent), 1 JPG lazy-loadé, 1 SVG favicon ; CSS/JS uniques sans dépendance ; pas de librairie externe.

## 17 — ACCESSIBILITY

Skip link, labels explicites, legends de fieldsets, erreurs en texte + `aria-invalid` + focus premier champ invalide, succès `role=status` + focus, accordéons `<details>` natifs, contrastes vérifiés (or profond #7A5E17 sur papier ≈ 5.6:1 ; encre sur or ≈ 7:1), focus visible or, reduced-motion.

## 18 — CODE

Livrable conforme à la règle de structure : `index.html` + `style.css` + `script.js` à la racine, `img/` à plat (logo-comparateurpro.png, section-protection-consultant.jpg, favicon.svg). Sections commentées dans le CSS et le JS. Point d'intégration endpoint signalé dans `script.js` (`/* === INTÉGRATION === */`).

## 19 — ANTI-AI AUDIT

DETECTED → FIX : compteurs/preuves sociales génériques → supprimés ; hero photo stock poignée de main → remplacé par le diagnostic ; 3 cartes avantages identiques → scènes numérotées asymétriques ; « devis gratuits rapides » → copy spécifique au métier ; badges multiples → un seul tag « Axe prioritaire » fonctionnel (exigence du brief).

## 20 — TRUTH CHECK

```yaml
truth_check:
  invented_facts: false
  invented_statistics: false
  invented_testimonials: false
  invented_clients: false
  invented_certifications: false
  invented_results: false
  unsupported_claims: false
  assumptions_marked: true   # H1-H4 listées en tête de document
```
Le « plus de 90 % des donneurs d'ordre » trouvé en recherche n'a PAS été repris (source intéressée, non vérifiable) → formulé « souvent exigée ».

## 21 — FINAL QA + CRO AUDIT

QA : strategy ✓ (cible/problème/promesse/angle/différenciation), ux ✓, ui ✓, cro ✓, responsive ✓, performance ✓, anti-template ✓, anti-ai ✓, truth ✓.
Vérifications exécutées : `node --check script.js` OK ; parse HTML équilibré OK ; smoke test jsdom **17/17 pass, 0 erreur runtime** (diagnostic→puces, validation inline, succès, retrait de puce) ; serveur HTTP : toutes les références (/, style.css, script.js, 3 assets img) en 200.

```yaml
cro_audit:
  value_proposition: 9
  clarity: 9
  differentiation: 9
  credibility: 8      # plafonné tant que le client ne fournit pas preuves réelles (DATA NEEDED)
  objection_handling: 9
  proof: 7            # volontairement sobre ; à monter avec les éléments client
  cta: 9
  friction: 9
  mobile_conversion: 9
```

## 22 — LP FINALE

Fichiers livrés à la racine du workspace : `index.html`, `style.css`, `script.js`, `img/` (3 assets). Préversion servie sur le port 8000. À compléter avant mise en ligne (DATA NEEDED) : endpoint du formulaire, mentions légales/ORIAS, politique de confidentialité, preuves réelles éventuelles (partenaires, chiffres, témoignages vérifiés).

---

# V2 — ITÉRATIONS CLIENT (2026-10-08)

Demandes client : (1) formulaire en haut à droite, premier élément sur mobile, redesign en 2 étapes ; (2) textes mieux ciblés consultants & sociétés de conseil ; (3) images réelles générées et insérées ; (4) parcours fluide pour utilisateur non technique.

## Modifications appliquées

1. **Formulaire hero, 2 étapes**
   - Desktop : copie à gauche, carte formulaire à droite (`grid-column 2`), liseré or pour signaler la zone d'action.
   - Mobile : formulaire **premier élément de la page** (`order:-1` sous 1000px).
   - Étape 1 « Votre besoin » : situation (pills) + axes à comparer (RC Pro / Multirisque badgés « Prioritaire », Santé / Prévoyance / Retraite en complément). Étape 2 « Vos coordonnées » : récapitulatif dynamique de l'étape 1, réalités de terrain facultatives (5 cases qui affinent la comparaison), contact, consentement.
   - Barre de progression 1/2 avec états `on`/`done`, bouton retour « ← Modifier mon besoin », focus guidé à chaque changement d'étape.

2. **Copywriting resserré sur la cible**
   - H1 : « Une RC Pro qui couvre vos missions chez le client, pas seulement vos bureaux. »
   - 3 puces scannables (axes prioritaires / compléments / 2 minutes) pour lecture non technique.
   - Scènes reformulées en situations vécues (« Le conseil qui engage », « Les données qu'on vous confie »…).
   - Multirisque repositionné société de conseil (locaux, équipe, obligations) ; nouvelle FAQ « société de conseil avec salariés » (3 étages : RC Pro structure, multirisque, santé/prévoyance employeur).
   - Libellés du formulaire en langage courant (« Quand votre travail est mis en cause »), contexte en phrases naturelles (« Je regarde, pour l'instant »).

3. **Images réelles insérées** : `scene-consultant-contrat.jpg` (colonne sticky « Vos risques réels »), `scene-equipe-conseil.jpg` (bloc multirisque en split), + `section-protection-consultant.jpg` conservée (bandeau perso). Lazy-load, alt descriptifs, dimensions déclarées.

4. **Fluidité non technique** : une seule action primaire par écran, progression visible, erreurs inline en langage clair, CTA final + sticky mobile ramenent au formulaire, « Comprendre en 1 minute » en CTA secondaire, reduced-motion respecté.

## Vérifications V2
- `node --check script.js` OK ; HTML équilibré OK.
- Smoke test jsdom du parcours complet : **17/17 pass, 0 erreur runtime** (erreur étape 1, passage 1→2, récap, retour 2→1, missions, envoi, succès).
- HTTP 200 sur les 3 photos + logo + favicon ; préversion port 8000.

---

# V3 — VOCABULAIRE & SIMPLICITÉ (2026-10-08)

Demandes client : éviter les mots répétitifs (« comparer »), effacer « prioritaire », LP simple et facile à comprendre, moins de mots techniques, UI/UX adaptée à la cible.

## Lexique appliqué
- Action : « faire ma demande » (CTA hero/header/sticky/final) ; livrable : « votre sélection d'offres » ; processus : « mettre les offres côte à côte », « nous lisons les contrats à votre place », « ce qu'on vérifie ».
- Audit final : racine « compar » = uniquement la marque (9× ComparateurPro + 2× nom de fichier logo) ; « prioritaire » = 0 ; « comparer/comparaison » hors marque = 0.
- Badges « Axe prioritaire / Prioritaire » supprimés (HTML + CSS). La hiérarchie passe par l'ordre (RC Pro et multirisque en premier) et le copywriting.

## Jargon traduit en langage courant
- « dommages immatériels non consécutifs » → « pertes financières de vos clients, même sans dégât matériel »
- « plafonds / sous-limites » → « montants maximums pris en charge » ; « franchises » → « ce qui reste à votre charge »
- « biens confiés » → « données et documents confiés » ; « fait des sous-traitants » → « erreurs d'un sous-traitant »
- « perte d'exploitation » → « activité à l'arrêt après un sinistre » ; « responsabilité d'exploitation » → « accident causé à un tiers » ; « protection juridique » → « aide juridique »
- Les « → À vérifier » des scènes deviennent des questions simples que l'utilisateur peut réellement poser.

## Vérifications V3
- `node --check` OK ; HTML équilibré ; smoke test jsdom **17/17 pass, 0 erreur** ; audit grep ci-dessus.
